
import './weapp-adapter';
import './laya/laya.core.js';
import './laya/laya.ani.js';
import './laya/laya.webgl.js';
import './laya/laya.ui.js';
import './laya/laya.wxmini.js';

Laya.MiniAdpter.init();
/*Laya.init(window.innerWidth, window.innerHeight ,WebGL);*/

import BackGround from './src/background';
var Stage = Laya.Stage;

Laya.init(window.innerWidth, window.innerHeight, Laya.WebGL);
Laya.stage.alignV = Stage.ALIGN_MIDDLE;
Laya.stage.alignH = Stage.ALIGN_CENTER;
Laya.stage.scaleMode = "showall";
Laya.stage.bgColor = "#000";
var backGround = new BackGround();
Laya.stage.addChild(backGround);

